Organise this mess
